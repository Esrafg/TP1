﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TP01_MVC.Models.Repositories
{
    public class EmployeeRepository: IRepository<Employee>
    {
        List<Employee> lemployees;

        public EmployeeRepository()
        {
            lemployees = new List<Employee>()
 {
 new Employee {Id=1,Name="Sofien ben ali", Departement= "comptabilité",Salary=1000},
 new Employee {Id=2,Name="Mourad triki", Departement= "RH",Salary=1500},
new Employee {Id=3,Name="ali ben mohamed", Departement= "informatique",Salary=1700},
 new Employee {Id=4,Name="tarak aribi", Departement= "informatique",Salary=1100}
 };
        }


        public void Add(Employee entity)
        {
            if (entity != null)
                lemployees.Add(entity);
           // throw new NotImplementedException();
        }

        public void Delete(int id)
        {
            var emp = FindByID(id);
            lemployees.Remove(emp);
            //throw new NotImplementedException();
        }

        public Employee FindByID(int id)
        {
            var emp = lemployees.FirstOrDefault(a => a.Id == id);
            return emp;
            //throw new NotImplementedException();
        }

        public IList<Employee> GetAll()
        {
            return lemployees;
            //throw new NotImplementedException();
        }

        public List<Employee> Search(string term)
        {
            if (!string.IsNullOrEmpty(term))
            {
                return lemployees.Where(a => a.Name.Contains(term)).ToList();
            }
            else
                return lemployees;
            //throw new NotImplementedException();
        }

        public void Update(int id, Employee entity)
        {
            var emp = FindByID(id);
            if (emp.Id == entity.Id)
            {
                emp.Name = entity.Name;
                emp.Departement = entity.Departement;
                emp.Salary = entity.Salary;
            }
          //  throw new NotImplementedException();
        }
        public double SalaryAverage()
        {
            return lemployees.Average(x => x.Salary);
        }
        public double MaxSalary()
        {
            return lemployees.Max(x => x.Salary);
        }
        public int HrEmployeesCount()
        {
            return lemployees.Where(x => x.Departement == "HR").Count();
        }
    }


}
