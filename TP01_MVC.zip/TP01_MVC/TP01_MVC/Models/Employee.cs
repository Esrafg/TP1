﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace TP01_MVC.Models
{
    public class Employee
    {
        public int Id { get; set; }
        [Required, StringLength(10,ErrorMessage="Taille max 10 characteres")]
        public string Name { get; set; }
        [Required]
        public string Departement { get; set; }
        [Range(200,5000)]
        public int Salary { get; set; }
    }

}
